let count = 0;
let input = document.querySelector('#todo-text');
let Btn1 = document.createElement('button');
let text = document.createElement('b');
let todoadd = () => {
    if (input.value === '') {
        alert("please enter something");
    }
    else {
        let parent = document.createElement('p');
        let Btn1 = document.createElement('button');
        let text = document.createElement('b');
        let date = document.createElement('b');
        let Btn2 = document.createElement('button');

        text.innerHTML = input.value;
        date.innerHTML = document.querySelector('#todo-date').value;
        Btn2.innerHTML = 'x';
        text.setAttribute('style', 'margin-left:30px; font-size:20px;');
        date.setAttribute('style', 'margin-left:30px;font-size:20px');
        id = 'p' + (++count);
        Btn1.setAttribute('class', 'unchecked');
        Btn1.setAttribute('onclick', `change('${id}')`);
        Btn2.setAttribute('style', 'float:right;font-size:15px;background-color:green;color:white;height:30px;width:50px');
        Btn2.setAttribute('onclick', `removeElement('${id}')`); //
        parent.append(Btn1);
        parent.append(text);
        parent.append(date);
        parent.append(Btn2);
        parent.setAttribute('class', 'todo-item');
        parent.setAttribute('style', 'width:100%');
        parent.setAttribute('id', id);

        document.querySelector('#main').appendChild(parent);


    }
    input.value = "";
    savedata();
}

function change(id) {
    c = document.querySelector(`#${id}`).getElementsByClassName('unchecked');
    // console.log(c)
    c[0].className="checked";
    document.querySelector(`#${id}`).className = 'c';
    d = document.querySelector(`#${id}`).getElementsByTagName('b');
    d[0].className = "text";
    savedata();
}
function removeElement(id) {
    // id.remove();
    document.querySelector('#main').removeChild
        (document.querySelector(`#${id}`));
    savedata();
}
function savedata() {
    localStorage.setItem("data", main.innerHTML);
}
function showtask() {
    document.querySelector('#main').innerHTML = localStorage.getItem("data");
}
function pending() {
    let pendingItems = document.querySelectorAll('.todo-item');
    let completedItems = document.querySelectorAll('.c');

    completedItems.forEach(item => {
        item.style.display = 'none';
    });

    pendingItems.forEach(item => {
        item.style.display = 'block';
    });
}

function completed() {
    let pendingItems = document.querySelectorAll('.todo-item');
    let completedItems = document.querySelectorAll('.c');

    pendingItems.forEach(item => {
        item.style.display = 'none';
    });

    completedItems.forEach(item => {
        item.style.display = 'block';
    });
}
showtask();
